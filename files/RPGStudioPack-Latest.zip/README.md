# 참고 이미지형 스킬 슬롯 HUD

## 적용

1. RPGStudioPack-RP3-Reference.zip을 Minecraft 리소스팩 폴더에 복사합니다.
2. RP-2 및 이전 RP-3 팩을 끄고 이번 Reference 팩만 켭니다.
3. 갱신한 RPGCore-0.2.jar가 서버 plugins에 배치되어 있습니다. 서버를 기존 방식으로 시작합니다.
4. RPG 무기를 1 또는 6~9번 슬롯에서 들고 확인합니다.

현재 실제 데이터는 스킬 1개이므로 2번에 아이콘, 3~5번에는 빈 프레임이 표시됩니다.
신규 스킬/무기 데이터는 생성하지 않았습니다.

## 참고 이미지에 맞춘 변경

- 위: 작은 어두운 탭에 2/3/4/5.
- 가운데: 어두운 테두리 + 기존 Skill PNG.
- 아래: 남은 쿨다운 초. 올림 정수로 표시하며 완료 시 숨김, 99초 초과는 99+.
- 번호를 아이콘 옆에 놓던 이전 가로 텍스트 배치는 제거했습니다.
- 슬롯 간격 18 GUI 픽셀, 전체 측정 폭 72픽셀로 고정했습니다.
- 아이콘 및 숫자를 그린 뒤 폭만큼 되돌리는 glyph를 넣어 숫자 길이와 PNG 폭으로 위치가 흔들리지 않게 했습니다.
- 중앙 기준에서 왼쪽으로 160 GUI 픽셀 이동합니다. 기준 텍스트 높이보다 내려서 핫바 왼쪽에 붙이는 배치입니다.
- 기본 26.2 HUD 좌표 계산상 바의 왼쪽은 화면 중앙-196, 아이콘 위는 화면 아래-31, 번호 탭 위는 아래-40, 쿨다운 위는 아래-13 GUI 픽셀입니다.

사진의 원본 아이콘 아트는 복원하지 않았습니다. 기존 Skill PNG를 보존하고 탭/프레임/숫자 아트만 코드로 만들었습니다.
사진과 모든 픽셀까지 동일하다고 검증한 상태는 아닙니다. 실제 게임 클라이언트 조작은 하지 않았습니다.

## 매핑과 파일

font: rpgcore:skill_icons
sword_slash_basic / dash_slash_basic / sword_wave_basic / whirlwind_basic → U+E001~E004.
빈/미등록 iconKey → U+E000.
기존 PNG: assets/minecraft/textures/gui/rpgcore/skills/
추가 PNG: assets/minecraft/textures/gui/rpgcore/hud/slot_frame.png, slot_keys.png, cooldown_digits.png
폰트: assets/rpgcore/font/skill_icons.json

build-pack.ps1은 실제 PNG 알파 영역에서 Minecraft 방식의 glyph advance를 계산하여 되돌림 여백을 생성합니다.
PNG 교체 후 build-pack.ps1 실행 → 새 ZIP 복사 → 팩 재적용/F3+T 순서로 갱신하세요.
Studio Hot Reload는 skillIds/iconKey와 서버 정의를 바꾸지만 클라이언트 PNG/폰트를 갱신하지 않습니다.
폰트 JSON 직접 수정은 다음 build-pack.ps1에서 덮어써집니다. 위치 수정은 빌드 스크립트의 ascent 및 위치 값과 Java 공간 문자 사용을 함께 확인해야 합니다.

## 제약

화면 모서리 고정이 아니라 기본 핫바의 중앙 기준 상대 배치입니다. GUI 너비가 약 392보다 작으면 왼쪽이 잘릴 수 있습니다.
해상도/GUI 배율/다른 HUD팩에 따른 차이가 있을 수 있습니다.
ActionBar 기반이므로 다른 플러그인과 표시 경쟁, 클라이언트 텍스트 배경 설정에 따른 기본 배경 표시가 남을 수 있습니다.
스킬 이름과 발동/오류 안내 문장은 HUD에서 표시하지 않습니다. 입력·Executor·쿨다운 저장 로직은 변경하지 않았습니다.

## 검증

Gradle build 성공. PNG 디코딩, JSON, glyph 매핑/advance 및 ZIP 구조 검사 통과.
validation/Rp3HudCheck.java에서 쿨다운 0/0.1/1/4.5/9/10/99/100/86400의 표시와 72px 폭 유지, 슬롯순서, 빈 슬롯, 무기/스냅샷 변경을 확인했습니다.
설치된 26.2.jar의 Hud.extractOverlayMessage(중앙, GUI 높이-68, 텍스트 y=-4)와 BitmapProvider 폭 계산을 읽어 좌표를 산출했습니다.
서버/게임은 이번 작업에서 실행하지 않았습니다. 위치와 실물 렌더링은 사용자가 확인합니다.
JAR SHA256: 6fdb9abf197ec3b9f955e167e668ab83d9c5a67245b24f16dce18bbf7663fb5c
백업: E:\MinecraftRPG\Backup\RPGStudio\rp3-reference-layout-20260927
